import csv

table = []
cities = []
cities_connect = []
connections = []
plan = []
plans = []
with open("test_task_data.csv", encoding='utf-8', newline='') as csvfile:
    reader = csv.reader(csvfile, delimiter=";")
    for row in reader:
        table.append(row)
    for row in table:
        if len(cities) == 0:
            cities.append(int(row[1]))
        else:
            repeat = 0
            for city in cities:
                if int(row[1]) == city:
                    repeat = 1
            if repeat == 0:
                cities.append(int(row[1]))
    print(cities)

    for city in cities:
        cities_connect=[]
        for row in table:
            if int(row[1]) == city:
                cities_connect.append(int(row[2]))
        connections.append(cities_connect)

    print(connections)




