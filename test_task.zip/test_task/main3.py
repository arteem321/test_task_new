import csv

def travel(train,current_city,append_city,reader,visited_cities, plan):
    visited_cities.append(current_city)
    plan.append(train)
    if len(visited_cities)<3 and len(plan)<3:
        for row in reader:
            repeat = 0
            for city in visited_cities:
                if int(row[2])==city:
                    repeat=1
            if int(row[1])==append_city and repeat!=1:
                if len(visited_cities) < 3:
                    travel(int(row[0]), int(row[1]), int(row[2]),reader, visited_cities,plan)
    elif len(visited_cities)==3 and len(plan)==3:
        plans.append(plan)


global plans
plans = []
table = []
with open("test_task_data.csv", encoding='utf-8', newline='') as csvfile:
    reader = csv.reader(csvfile, delimiter=";")
    for row in reader:
        table.append(row)
    for row in table:
        visited_cities=[]
        plan=[]
        travel(int(row[0]), int(row[1]), int(row[2]), table, visited_cities, plan)
print(plans)