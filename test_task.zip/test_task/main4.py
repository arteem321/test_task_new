import csv


def new_travel(CITIES, CURRENT_CITY, CURRENT_INDEX, VISITED_CITIES, NEW_CONNECTIONS):
    V_CITIES = VISITED_CITIES
    V_CITIES.append(CURRENT_CITY)
    while True:
        if len(VISITED_CITIES) == len(CITIES):
            print(V_CITIES)
            break
        for j in range(len(NEW_CONNECTIONS[CURRENT_INDEX])):
            future_city = NEW_CONNECTIONS[CURRENT_INDEX][j]
            REPEAT=0
            for CITY in V_CITIES:
                if CITY == future_city:
                    REPEAT = 1
            if REPEAT == 0:
                for k in range(len(CITIES)):
                    if CITIES[k] == CURRENT_CITY:
                        current_index = k
                new_travel(CITIES, future_city, current_index, V_CITIES, NEW_CONNECTIONS)



def travel(current_city, unvisited_cities, step, connections, way):
    self_step=step+1
    for city in unvisited_cities:
        if city==current_city:
            unvisited_cities.pop(unvisited_cities.index(city))
    if len(unvisited_cities)!=0:
        for connection in connections:
            if connection[0]==current_city:
                repeat=0
                for city in unvisited_cities:
                    if connection[1]==city:
                        repeat=1
                if repeat==1:
                    new_way=[]
                    for w in way:
                        new_way.append(w)
                    new_way.append(connection[1])
                    travel(connection[1],unvisited_cities,self_step,connections,new_way)
                else:
                    for w in way:
                        if current_city==w:
                            way.pop(way.index(w))
    else:
        print(way)


table = []
short_table = []
cities = []
connections = []
road = []

with open("test_task_data.csv", encoding='utf-8', newline='') as csvfile:
    reader = csv.reader(csvfile, delimiter=";")
    for row in reader:
        table.append(row)
    for row in table:
        if len(cities) == 0:
            cities.append(int(row[1]))
        else:
            repeat = 0
            for city in cities:
                if int(row[1]) == city:
                    repeat = 1
            if repeat == 0:
                cities.append(int(row[1]))

    for row in table:
        if len(short_table)==0:
            a=1
            short_table.append([int(row[1]),int(row[2])])
        else:
            repeat = 0
            for row2 in short_table:
                if int(row[1])==int(row2[0]) and int(row[2])==int(row2[1]):
                    repeat=1
            if repeat==0:
                a+=1
                short_table.append([int(row[1]), int(row[2])])

    for city in cities:
        for row in short_table:
            if int(row[0])==city:
                connections.append([city,row[1]])

    new_connections=[]
    for city in cities:
        connection = []
        for row in short_table:
            if int(row[0])==city:
                connection.append(row[1])
        new_connections.append(connection)

    print(cities)
    print(short_table)
    print(connections)
    print(new_connections)

    # for city in cities:
    #     road=[]
    #     road.append(city)
    #     travel(city,cities,1,connections,road)

    for i in range(len(cities)):
        new_travel(cities,cities[i],i,[],new_connections)

